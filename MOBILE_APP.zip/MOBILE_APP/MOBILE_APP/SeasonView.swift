//
//  SeasonView.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/16/22.
//

import SwiftUI

struct SeasonView: View {
    
    @State var lightGray: Color = Color(hue: 1.0, saturation: 0.0, brightness: 0.902)
    
    var body: some View {
        
        VStack() {
            Spacer()
                
            
//            HStack() {
//                NavigationLink(destination: PointTrackerView()) {
//                    Text("Game 1")
//
//                }.frame(width: 150, height: 30).padding().background(lightGray).cornerRadius(20).accentColor(.black)
//                    .navigationBarBackButtonHidden(true)
//            }
//            NavigationLink(destination: PointTrackerView()) {
//                Text("Game 2")
//
//            }.frame(width: 150, height: 30).padding().background(lightGray).cornerRadius(20).accentColor(.black)
//                .navigationBarBackButtonHidden(true)
            Spacer()
            Spacer()
            NavigationLink(destination: PointTrackerView()) {
                Text("START\nGAME").fontWeight(.black).font(.system(size : 40)).bold()

            }.frame(width: 200, height: 200).padding().background(.green).cornerRadius(150).accentColor(.black).navigationBarBackButtonHidden(true)
            Spacer()
            if (game1.myGoals == 0 && game1.oppGoals == 0 && game1.wins == 0 && game1.loss == 0) {
                Button("STATS") {
                
                }.padding().background(lightGray).cornerRadius(30).accentColor(.gray)
            }
            else {
                NavigationLink(destination: PointsPlayedView()) {
                    Text("STATS")
                        .padding().background(.gray).accentColor(.black)
                }.cornerRadius(30)
            }
        }
    }
}

struct SeasonView_Previews: PreviewProvider {
    static var previews: some View {
        SeasonView()
    }
}
