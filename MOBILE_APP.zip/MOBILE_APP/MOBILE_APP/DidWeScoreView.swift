//
//  DidWeScoreView.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/11/22.
//

import SwiftUI

struct DidWeScoreView: View {

    
    var body: some View {
        VStack {
        Text("").font(.system(size : 40)).fontWeight(.bold)
            HStack {
                NavigationLink(destination: WhoScoredView()) {
                    Text("YES").font(.system(size : 40)).fontWeight(.bold)
                }.simultaneousGesture(TapGesture().onEnded{
                    game1.incMe()
                }).padding().background(.green).cornerRadius(20)
                NavigationLink(destination: DidAnyoneBlockView()) {
                    Text(" NO ").font(.system(size : 40)).fontWeight(.bold)
                }.simultaneousGesture(TapGesture().onEnded{
                    game1.incThem()
                }).padding().background(.green).cornerRadius(20)
                
            }
        }
    }
}

struct DidWeScoreView_Previews: PreviewProvider {
    static var previews: some View {
        DidWeScoreView()
    }
}
