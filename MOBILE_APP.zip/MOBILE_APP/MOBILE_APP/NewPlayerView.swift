//
//  NewPlayerView.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/7/22.
//

import SwiftUI


struct NewPlayerView: View {
    @State var names: String = ""
    @State var playerNum: Int = 0
    
    
    var body: some View {
        VStack {
        Spacer()
        Text("Enter Roster")
                .bold().fontWeight(.black)
                .multilineTextAlignment(.leading).font(.system(size : 50))
        Text("(Limit 28 Players)")
        Spacer()
            TextField(" Enter Name", text: $names)
                .border(.gray).frame(width: 350).background(Color(red: 0.933, green: 0.933, blue: 0.933))
            Spacer()
            if (names == "" || playerNum == 28) {
                Button("Enter Player") {
                
                }.padding(30).background(Color(red: 0.933, green: 0.933, blue: 0.933)).cornerRadius(50).accentColor(.gray)
            } else {
                Button("Enter Player") {
                    if (!jordan.exists) {
                        jordan.name = names
                        jordan.exists = true
                        names = ""
                    } else if (!joe.exists) {
                        joe.name = names
                        joe.exists = true
                        names = ""
                    } else if (!jmills.exists) {
                        jmills.name = names
                        jmills.exists = true
                        names = ""
                    } else if (!asteph.exists) {
                        asteph.name = names
                        asteph.exists = true
                        names = ""
                    } else if (!logan.exists) {
                        logan.name = names
                        logan.exists = true
                        names = ""
                    } else if (!luke.exists) {
                        luke.name = names
                        luke.exists = true
                        names = ""
                    } else if (!austin.exists) {
                        austin.name = names
                        austin.exists = true
                        names = ""
                    } else if (!brody.exists) {
                        brody.name = names
                        brody.exists = true
                        names = ""
                    } else if (!bj.exists) {
                        bj.name = names
                        bj.exists = true
                        names = ""
                    } else if (!jackson.exists) {
                        jackson.name = names
                        jackson.exists = true
                        names = ""
                    } else if (!jz.exists) {
                        jz.name = names
                        jz.exists = true
                        names = ""
                    } else if (!johnny.exists) {
                        johnny.name = names
                        johnny.exists = true
                        names = ""
                    } else if (!shawn.exists) {
                        shawn.name = names
                        shawn.exists = true
                        names = ""
                    } else if (!bryce.exists) {
                        bryce.name = names
                        bryce.exists = true
                        names = ""
                    } else if (!chad.exists) {
                        chad.name = names
                        chad.exists = true
                        names = ""
                    } else if (!fletch.exists) {
                        fletch.name = names
                        fletch.exists = true
                        names = ""
                    } else if (!kalten.exists) {
                        kalten.name = names
                        kalten.exists = true
                        names = ""
                    } else if (!porter.exists) {
                        porter.name = names
                        porter.exists = true
                        names = ""
                    } else if (!taylor.exists) {
                        taylor.name = names
                        taylor.exists = true
                        names = ""
                    } else if (!andrew.exists) {
                        andrew.name = names
                        andrew.exists = true
                        names = ""
                    } else if (!evan.exists) {
                        evan.name = names
                        evan.exists = true
                        names = ""
                    } else if (!fischer.exists) {
                        fischer.name = names
                        fischer.exists = true
                        names = ""
                    } else if (!isaac.exists) {
                        isaac.name = names
                        isaac.exists = true
                        names = ""
                    } else if (!jensen.exists) {
                        jensen.name = names
                        jensen.exists = true
                        names = ""
                    } else if (!hanni.exists) {
                        hanni.name = names
                        hanni.exists = true
                        names = ""
                    } else if (!jonathan.exists) {
                        jonathan.name = names
                        jonathan.exists = true
                        names = ""
                    } else if (!tyler.exists) {
                        tyler.name = names
                        tyler.exists = true
                        names = ""
                    } else if (!zach.exists) {
                        zach.name = names
                        zach.exists = true
                        names = ""
                    } else {
                        names = "TOO MANY PLAYERS"
                    }
                    playerNum += 1
                    // CONSEQUENCE, players aren't playing where they are most needed to play
                    
                    
                
                }.padding(30).background(.green).cornerRadius(50).accentColor(.black)
            }
            if (playerNum == 0) {
                Button("Finished") {
                
                }.padding(30).background(Color(red: 0.933, green: 0.933, blue: 0.933)).cornerRadius(50).accentColor(.gray)
            } else {
                NavigationLink(destination: SeasonView()) {
                    Text("FINISHED").fontWeight(.black)
                        .padding(30)
                        .background(.green)
                }.accentColor(.black).cornerRadius(50)
            }
            Spacer()
        }
        
    }
}

struct NewPlayerView_Previews: PreviewProvider {
    static var previews: some View {
        NewPlayerView()
    }
}
