//
//  PointsPlayedView.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/7/22.
//"+/-       PTS       AST       BLK         PLAYER NAME"
//.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))

import SwiftUI
// ADDED 4 BETWEEN  11/11/
struct PointsPlayedView: View {
    var body: some View {
        VStack{
            Text("             NAME                         PTS        GLS        AST        BLK         TO         +/-").fontWeight(.bold).frame(maxWidth: .infinity, alignment: .leading).padding().font(.system(size : 10))
            ScrollView {
                    VStack(spacing: 0) {
                        
                        if (jordan.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(jordan.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(jordan.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jordan.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jordan.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(jordan.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jordan.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jordan.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        
                        if (joe.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(joe.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(joe.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(joe.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(joe.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(joe.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(joe.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(joe.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        
                        if (jmills.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(jmills.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(jmills.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jmills.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jmills.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(jmills.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jmills.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jmills.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        
                        
                        if (asteph.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(asteph.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(asteph.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(asteph.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(asteph.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(asteph.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(asteph.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(asteph.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        
                        if (logan.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(logan.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(logan.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(logan.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(logan.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(logan.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(logan.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(logan.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        
                        if (luke.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(luke.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(luke.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(luke.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(luke.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(luke.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(luke.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(luke.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        
                        if (austin.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(austin.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(austin.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(austin.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(austin.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(austin.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(austin.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(austin.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                    }
                
                    VStack(spacing: 0) {
                        if (brody.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(brody.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(brody.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(brody.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(brody.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(brody.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(brody.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(brody.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        if (bj.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(bj.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(bj.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(bj.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(bj.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(bj.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(bj.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(bj.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        if (jackson.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(jackson.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(jackson.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jackson.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jackson.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(jackson.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jackson.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jackson.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        if (jz.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(jz.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(jz.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jz.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jz.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(jz.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jz.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jz.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        if (johnny.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(johnny.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(johnny.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(johnny.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(johnny.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(johnny.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(johnny.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(johnny.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        if (shawn.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(shawn.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(shawn.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(shawn.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(shawn.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(shawn.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(shawn.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(shawn.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                    }
                    VStack(spacing: 0) {
                        if (bryce.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(bryce.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(bryce.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(bryce.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(bryce.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(bryce.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(bryce.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(bryce.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        if (chad.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(chad.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(chad.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(chad.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(chad.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(chad.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(chad.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(chad.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        if (fletch.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(fletch.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(fletch.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(fletch.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(fletch.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(fletch.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(fletch.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(fletch.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        if (kalten.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(kalten.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(kalten.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(kalten.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(kalten.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(kalten.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(kalten.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(kalten.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        if (porter.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(porter.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(porter.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(porter.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(porter.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(porter.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(porter.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(porter.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        if (taylor.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(taylor.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(taylor.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(taylor.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(taylor.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(taylor.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(taylor.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(taylor.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        if (andrew.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(andrew.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(andrew.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(andrew.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(andrew.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(andrew.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(andrew.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(andrew.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        if (evan.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(evan.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(evan.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(evan.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(evan.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(evan.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(evan.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(evan.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                    }
                    VStack(spacing: 0) {
                        if (fischer.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(fischer.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(fischer.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(fischer.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(fischer.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(fischer.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(fischer.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(fischer.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        if (isaac.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(isaac.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(isaac.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(isaac.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(isaac.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(isaac.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(isaac.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(isaac.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        if (jensen.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(jensen.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(jensen.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jensen.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jensen.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(jensen.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jensen.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jensen.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        if (hanni.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(hanni.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(hanni.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(hanni.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(hanni.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(hanni.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(hanni.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(hanni.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        if (jonathan.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(jonathan.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(jonathan.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jonathan.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jonathan.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(jonathan.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jonathan.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(jonathan.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        if (tyler.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(tyler.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(tyler.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(tyler.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(tyler.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(tyler.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(tyler.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(tyler.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding().background(Color(red: 0.933, green: 0.933, blue: 0.933))
                        }
                        if (zach.pointsPlayed > 0) {
                            HStack() {
                                HStack() {
                                    Text("\(zach.getname())").frame(width: 120)
                                    Divider()
                                    Text("\(zach.getPP())").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(zach.goals)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(zach.assists)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    
                                }
                                HStack() {
                                    Text("\(zach.blocks)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(zach.turnover)").fontWeight(.bold).frame(width: 25, height: 20)
                                    Divider()
                                    Text("\(zach.getPM())").fontWeight(.bold).frame(width: 25, height: 20)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading).padding()
                        }
                        
                }
            }
        }
    }
}

struct PointsPlayedView_Previews: PreviewProvider {
    static var previews: some View {
        PointsPlayedView()
    }
}
