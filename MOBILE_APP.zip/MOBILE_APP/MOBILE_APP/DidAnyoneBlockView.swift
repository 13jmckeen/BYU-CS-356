//
//  DidAnyoneBlockView.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/14/22.
//

import SwiftUI

struct DidAnyoneBlockView: View {
    @State private var jordanKerrScore = false
    @State private var joeMerrillScore = false
    @State private var jacobMillerScore = false
    @State private var andrewStephenScore = false
    @State private var loganClarkeScore = false
    @State private var lukeYorgasonScore = false
    @State private var austinRichScore = false
    @State private var brodyDobsonScore = false
    @State private var brandonJordanScore = false
    @State private var jacksonGardnerScore = false
    @State private var jacobZundelScore = false
    @State private var jonathanMerrillScore = false
    @State private var shawnWilkeyScore = false
    @State private var bryceKerrScore = false
    @State private var chadYorgasonScore = false
    @State private var fletcherMillerScore = false
    @State private var kaltenTooneScore = false
    @State private var porterOylerScore = false
    @State private var taylorWilliamsScore = false
    @State private var andrewMillerScore = false
    @State private var evanMillerScore = false
    @State private var fischerDastrupScore = false
    @State private var isaacRasmussenScore = false
    @State private var jensenWellsScore = false
    @State private var johnHanniScore = false
    @State private var jonathanScore = false
    @State private var tylerJensenScore = false
    @State private var zachSaetrumScore = false
    @State var lightGray: Color = Color(hue: 1.0, saturation: 0.0, brightness: 0.902)
    
    
    var body: some View {
        VStack {
            Text("Did Anyone Block?").fontWeight(.bold)
            ScrollView {
                VStack {
                    if (jordan.isOnField == true) {
                    Toggle(isOn: $jordanKerrScore) {
                        Text("\(jordan.name)")
                    }.padding()
                    }
                    if (joe.isOnField == true) {
                    Toggle(isOn: $joeMerrillScore) {
                        Text("\(joe.name)")
                    }.padding()
                    }
                    if (jmills.isOnField == true) {
                    Toggle(isOn: $jacobMillerScore) {
                        Text("\(jmills.name)")
                    }.padding()
                    }
                    if (asteph.isOnField == true) {
                    Toggle(isOn: $andrewStephenScore) {
                        Text("\(asteph.name)")
                    }.padding()
                    }
                    if (logan.isOnField == true) {
                    Toggle(isOn: $loganClarkeScore) {
                        Text("\(logan.name)")
                    }.padding()
                    }
                    if (luke.isOnField == true) {
                    Toggle(isOn: $lukeYorgasonScore) {
                        Text("\(luke.name)")
                    }.padding()
                    }
                    if (austin.isOnField == true) {
                    Toggle(isOn: $austinRichScore) {
                        Text("\(austin.name)")
                    }.padding()
                    }
                    if (brody.isOnField == true) {
                    Toggle(isOn: $brodyDobsonScore) {
                        Text("\(brody.name)")
                    }.padding()
                    }
                    
                }
                VStack {
                    if (bj.isOnField == true) {
                    Toggle(isOn: $brandonJordanScore) {
                        Text("\(bj.name)")
                    }.padding()
                    }
                    if (jackson.isOnField == true) {
                    Toggle(isOn: $jacksonGardnerScore) {
                        Text("\(jackson.name)")
                    }.padding()
                    }
                    if (jz.isOnField == true) {
                    Toggle(isOn: $jacobZundelScore) {
                        Text("\(jz.name)")
                    }.padding()
                    }
                    if (johnny.isOnField == true) {
                    Toggle(isOn: $jonathanMerrillScore) {
                        Text("\(johnny.name)")
                    }.padding()
                    }
                    if (shawn.isOnField == true) {
                    Toggle(isOn: $shawnWilkeyScore) {
                        Text("S\(shawn.name)")
                    }.padding()
                    }
                    if (bryce.isOnField == true) {
                    Toggle(isOn: $bryceKerrScore) {
                        Text("\(bryce.name)")
                    }.padding()
                    }
                    if (chad.isOnField == true) {
                    Toggle(isOn: $chadYorgasonScore) {
                        Text("\(chad.name)")
                    }.padding()
                    }
                    if (fletch.isOnField == true) {
                    Toggle(isOn: $fletcherMillerScore) {
                        Text("\(fletch.name)")
                    }.padding()
                    }
                }
                VStack {
                    if (kalten.isOnField == true) {
                    Toggle(isOn: $kaltenTooneScore) {
                        Text("\(kalten.name)")
                    }.padding()
                    }
                    if (porter.isOnField == true) {
                    Toggle(isOn: $porterOylerScore) {
                        Text("\(porter.name)")
                    }.padding()
                    }
                    if (taylor.isOnField == true) {
                    Toggle(isOn: $taylorWilliamsScore) {
                        Text("\(taylor.name)")
                    }.padding()
                    }
                    if (andrew.isOnField == true) {
                    Toggle(isOn: $andrewMillerScore) {
                        Text("\(andrew.name)")
                    }.padding()
                    }
                    if (evan.isOnField == true) {
                    Toggle(isOn: $evanMillerScore) {
                        Text("\(evan.name)")
                    }.padding()
                    }
                    if (fischer.isOnField == true) {
                    Toggle(isOn: $fischerDastrupScore) {
                        Text("\(fischer.name)")
                    }.padding()
                    }
                }
                VStack {
                    if (isaac.isOnField == true) {
                    Toggle(isOn: $isaacRasmussenScore) {
                        Text("\(isaac.name)")
                    }.padding()
                    }
                    if (jensen.isOnField == true) {
                    Toggle(isOn: $jensenWellsScore) {
                        Text("\(jensen.name)")
                    }.padding()
                    }
                    if (hanni.isOnField == true) {
                    Toggle(isOn: $johnHanniScore) {
                        Text("\(hanni.name)")
                    }.padding()
                    }
                    if (jonathan.isOnField == true) {
                    Toggle(isOn: $jonathanScore) {
                        Text("\(jonathan.name)")
                    }.padding()
                    }
                    if (tyler.isOnField == true) {
                    Toggle(isOn: $tylerJensenScore) {
                        Text("\(tyler.name)")
                    }.padding()
                    }
                    if (zach.isOnField == true) {
                    Toggle(isOn: $zachSaetrumScore) {
                        Text("\(zach.name)")
                    }.padding()
                    }
                }
            }
            Spacer()
            NavigationLink(destination: OffenseView()) {
                Text("CONTINUE")
            }.simultaneousGesture(TapGesture().onEnded{
                if (jordanKerrScore) {
                    jordan.incBlock()
                }
                if (joeMerrillScore) {
                    joe.incBlock()
                }
                if (jacobMillerScore) {
                    jmills.incBlock()
                }
                if (andrewStephenScore) {
                    asteph.incBlock()
                }
                if (loganClarkeScore) {
                    logan.incBlock()
                }
                if (lukeYorgasonScore) {
                    luke.incBlock()
                }
                if (austinRichScore) {
                    austin.incBlock()
                }
                if (brodyDobsonScore) {
                    brody.incBlock()
                }
                if (brandonJordanScore) {
                    bj.incBlock()
                }
                if (jacksonGardnerScore) {
                    jackson.incBlock()
                }
                if (jacobZundelScore) {
                    jz.incBlock()
                }
                if (jonathanMerrillScore) {
                    johnny.incBlock()
                }
                if (shawnWilkeyScore) {
                    shawn.incBlock()
                }
                if (bryceKerrScore) {
                    bryce.incBlock()
                }
                if (chadYorgasonScore) {
                    chad.incBlock()
                }
                if (fletcherMillerScore) {
                    fletch.incBlock()
                }
                if (kaltenTooneScore) {
                    kalten.incBlock()
                }
                if (porterOylerScore) {
                    porter.incBlock()
                }
                if (taylorWilliamsScore) {
                    taylor.incBlock()
                }
                if (andrewMillerScore) {
                    andrew.incBlock()
                }
                if (evanMillerScore) {
                    evan.incBlock()
                }
                if (fischerDastrupScore) {
                    fischer.incBlock()
                }
                if (isaacRasmussenScore) {
                    isaac.incBlock()
                }
                if (jensenWellsScore) {
                    jensen.incBlock()
                }
                if (johnHanniScore) {
                    hanni.incBlock()
                }
                if (jonathanScore) {
                    jonathan.incBlock()
                }
                if (tylerJensenScore) {
                    tyler.incBlock()
                }
                if (zachSaetrumScore) {
                    zach.incBlock()
                }
            }).padding().background(.gray).cornerRadius(30).accentColor(.black)
        }
    }
}

struct DidAnyoneBlockView_Previews: PreviewProvider {
    static var previews: some View {
        DidAnyoneBlockView()
    }
}
