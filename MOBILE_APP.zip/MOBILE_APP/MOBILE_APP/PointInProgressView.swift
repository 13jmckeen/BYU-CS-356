//
//  PointInProgressView.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/29/22.
//

import SwiftUI

struct PointInProgressView: View {
    var body: some View {
        VStack {
        Text("ARE WE ON OFFENSE?").font(.system(size : 40)).fontWeight(.bold)
            HStack {
                NavigationLink(destination: OffenseView()) {
                    Text("YES").font(.system(size : 40)).fontWeight(.bold)
                }.simultaneousGesture(TapGesture().onEnded{
                    game1.players = 0
                }).padding().background(.green).cornerRadius(20).accentColor(.black)
                NavigationLink(destination: DefenseView()) {
                    Text(" NO ").font(.system(size : 40)).fontWeight(.bold)
                }.simultaneousGesture(TapGesture().onEnded{
                    game1.players = 0
                }).padding().background(.green).cornerRadius(20).accentColor(.black)
                
            }
        }
    }
}

struct PointInProgressView_Previews: PreviewProvider {
    static var previews: some View {
        PointInProgressView()
    }
}
