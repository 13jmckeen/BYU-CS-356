//
//  PointTrackerView.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/7/22.
//

import SwiftUI
import UIKit
struct Game {
    var myGoals = 0
    var oppGoals = 0
    var wins = 0
    var loss = 0
    var players = 0
    
    mutating func incMe() {
        myGoals += 1
    }
    mutating func incThem() {
        oppGoals += 1
    }
}

struct Player {
    var name: String
    var pointsPlayed = 0
    var blocks = 0
    var assists = 0
    var goals = 0
    var turnover = 0
    var isOnField = false
    var exists = false
    
    mutating func setName(newName: String) {
        name = newName
    }
     func getname() -> String {
        return name
    }
    func getPP() -> Int {
        return pointsPlayed
    }
    mutating func incGoals() {
        goals += 1
    }
    mutating func incAsst() {
        assists += 1
    }
    mutating func incBlock() {
        blocks += 1
    }
    mutating func incTurns() {
        turnover += 1
    }
    mutating func increment() {
        pointsPlayed += 1
    }
    mutating func turnOnField() {
        isOnField = true
    }
    mutating func turnOffField() {
        isOnField = false
    }
    func getPM() -> Int {
        return goals + assists + blocks - turnover
    }
}


var joe = Player(name:"Joseph Merrill")
var jordan = Player(name:"Jordan Kerr")
var jmills = Player(name:"Jacob Miller")
var asteph = Player(name:"Andrew Stephen")
var logan = Player(name:"Logan Clarke")
var luke = Player(name:"Luke Yorgason")
var austin = Player(name:"Austin Rich")
var brody = Player(name:"Brody Dobson")
var bj = Player(name: "Brandon Jordan")
var jackson = Player(name: "Jackson Gardner")
var jz = Player(name: "Jacob Zundel")
var johnny = Player(name: "Jonathan Merrill")
var shawn = Player(name: "Shawn Wilkey")
var bryce = Player(name: "Bryce Kerr")
var chad = Player(name: "Chad Yorgason")
var fletch = Player(name: "Fletcher Miller")
var kalten = Player(name: "Kalten Toone")
var porter = Player(name: "Porter Oyler")
var taylor = Player(name: "Taylor Williams")
var andrew = Player(name: "Andrew Miller")
var evan = Player(name: "Evan Miller")
var fischer = Player(name: "Fischer Dastrup")
var isaac = Player(name: "Isaac Rasmussen")
var jensen = Player(name: "Jensen Wells")
var hanni = Player(name: "John Hanni")
var jonathan = Player(name: "Jonathan Miller")
var tyler = Player(name: "Tyler Jensen")
var zach = Player(name: "Zach Saetrum")

var myArray = [Player(name:"Justin McKeen"),
               Player(name:"Joe Merrill"),
               Player(name:"Jordan Kerr")]

var game1 = Game()
var game2 = Game()









struct PointTrackerView: View {
    @State private var areWeOnOffense = false
    
    @State private var jordanKerrButton = false
    @State private var joeMerrillButton = false
    @State private var jacobMillerButton = false
    @State private var andrewStephenButton = false
    @State private var loganClarkeButton = false
    @State private var lukeYorgasonButton = false
    @State private var austinRichButton = false
    @State private var brodyDobsonButton = false
    @State private var brandonJordanButton = false
    @State private var jacksonGardnerButton = false
    @State private var jacobZundelButton = false
    @State private var jonathanMerrillButton = false
    @State private var shawnWilkeyButton = false
    @State private var bryceKerrButton = false
    @State private var chadYorgasonButton = false
    @State private var fletcherMillerButton = false
    @State private var kaltenTooneButton = false
    @State private var porterOylerButton = false
    @State private var taylorWilliamsButton = false
    @State private var andrewMillerButton = false
    @State private var evanMillerButton = false
    @State private var fischerDastrupButton = false
    @State private var isaacRasmussenButton = false
    @State private var jensenWellsButton = false
    @State private var johnHanniButton = false
    @State private var jonathanButton = false
    @State private var tylerJensenButton = false
    @State private var zachSaetrumButton = false
    
    @State private var selectedPlayer1: Player = jordan
    
    @State var lightGray: Color = Color(hue: 1.0, saturation: 0.0, brightness: 0.902)
    

    var body: some View {
        // IDEAS: Depending on offense/defense? We prompt who got the goal/assist/d/ maybe a turnover?
        // Break it up into individual games? Start with team names -> game to what? -> Starting on O/D -> score keeping -> Record & stats over the weekend? LOOK AT WHAT ERIC JACOBSON DID FOR BYU WITH THOSE STAT PAGES
        // START TOURNAMENT -> GAME 1 -> into my main functionality
        // TABS ON BOTTOM? - Total stats - game by game stats - 
        
        
        
        
        
        VStack() {
            Spacer()
            VStack() {
                HStack() {
                    Text(" YOU  ")
                        .fontWeight(.black)
                        .multilineTextAlignment(.leading).font(.system(size : 50))
                    Text("\(game1.myGoals)").font(.system(size : 40))
                    Spacer()
                    Text("-").font(.system(size : 40))
                    Spacer()
                    Text("\(game1.oppGoals)").font(.system(size : 40))
                    Text("  OPP ").fontWeight(.black)
                        .multilineTextAlignment(.leading).font(.system(size : 50))
                }.frame(maxWidth: .infinity)
                HStack() {
                    Text("     ")
                    Text("(\(game1.wins) - \(game1.loss))")
                    Spacer()
                }
            }
            Spacer()
            Spacer()
            Divider()
            Text("SWIPE 7 PLAYERS ON LINE").fontWeight(.bold)
            Spacer()
            
            
            ScrollView {
                VStack(spacing: 0) {
                    /*
                     iPhone 14 Pro
                    HStack(spacing: 2) {
                        Spacer()
                        if (!jordan.exists) {
                            Button("\(jordan.getname())") {
                                if (jordanKerrButton == false) {
                                    jordanKerrButton = true
                                } else {
                                    jordanKerrButton = false
                                }
                                
                            }.frame(width: 150, height: 30).padding().background(lightGray).cornerRadius(20)
                        }
                        Spacer()
                        if (!jordan.exists) {
                            Button("\(jordan.getname())") {
                                if (jordanKerrButton == false) {
                                    jordanKerrButton = true
                                } else {
                                    jordanKerrButton = false
                                }
                            }.frame(width: 150, height: 30).padding().background(.green).cornerRadius(20)
                            Spacer()
                        }
                        
                    }
                        */
                    if (jordan.exists) {
                        Toggle(isOn: $jordanKerrButton) {
                            Text(jordan.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!jordanKerrButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }}).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (joe.exists) {
                        Toggle(isOn: $joeMerrillButton) {
                            Text(joe.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!joeMerrillButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                    if (jmills.exists) {
                        Toggle(isOn: $jacobMillerButton) {
                            Text(jmills.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!jacobMillerButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (asteph.exists) {
                        Toggle(isOn: $andrewStephenButton) {
                            Text(asteph.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!andrewStephenButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                    if (logan.exists) {
                        Toggle(isOn: $loganClarkeButton) {
                            Text(logan.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!loganClarkeButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (luke.exists) {
                        Toggle(isOn: $lukeYorgasonButton) {
                            Text(luke.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!lukeYorgasonButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                    if (austin.exists) {
                        Toggle(isOn: $austinRichButton) {
                            Text(austin.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!austinRichButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (brody.exists) {
                        Toggle(isOn: $brodyDobsonButton) {
                            Text(brody.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!brodyDobsonButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                }
                VStack(spacing: 0) {
                    if (bj.exists) {
                        Toggle(isOn: $brandonJordanButton) {
                            Text(bj.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!brandonJordanButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (jackson.exists) {
                        Toggle(isOn: $jacksonGardnerButton) {
                            Text(jackson.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!jacksonGardnerButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                    if (jz.exists) {
                        Toggle(isOn: $jacobZundelButton) {
                            Text(jz.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!jacobZundelButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (johnny.exists) {
                        Toggle(isOn: $jonathanMerrillButton) {
                            Text(johnny.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!jonathanMerrillButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                    if (shawn.exists) {
                        Toggle(isOn: $shawnWilkeyButton) {
                            Text(shawn.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!shawnWilkeyButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (bryce.exists) {
                        Toggle(isOn: $bryceKerrButton) {
                            Text(bryce.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!bryceKerrButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                    if (chad.exists) {
                        Toggle(isOn: $chadYorgasonButton) {
                            Text(chad.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!chadYorgasonButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (fletch.exists) {
                        Toggle(isOn: $fletcherMillerButton) {
                            Text(fletch.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!fletcherMillerButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                }
                VStack(spacing: 0) {
                    if (kalten.exists) {
                        Toggle(isOn: $kaltenTooneButton) {
                            Text(kalten.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!kaltenTooneButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (porter.exists) {
                        Toggle(isOn: $porterOylerButton) {
                            Text(porter.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!porterOylerButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                    if (taylor.exists) {
                        Toggle(isOn: $taylorWilliamsButton) {
                            Text(taylor.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!taylorWilliamsButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (andrew.exists) {
                        Toggle(isOn: $andrewMillerButton) {
                            Text(andrew.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!andrewMillerButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                    if (evan.exists) {
                        Toggle(isOn: $evanMillerButton) {
                            Text(evan.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!evanMillerButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (fischer.exists) {
                        Toggle(isOn: $fischerDastrupButton) {
                            Text(fischer.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!fischerDastrupButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                }
                VStack(spacing: 0) {
                    if (isaac.exists) {
                        Toggle(isOn: $isaacRasmussenButton) {
                            Text(isaac.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!isaacRasmussenButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (jensen.exists) {
                        Toggle(isOn: $jensenWellsButton) {
                            Text(jensen.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!jensenWellsButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                    if (hanni.exists) {
                        Toggle(isOn: $johnHanniButton) {
                            Text(hanni.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!johnHanniButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (jonathan.exists) {
                        Toggle(isOn: $jonathanButton) {
                            Text(jonathan.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!jonathanButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                    if (tyler.exists) {
                        Toggle(isOn: $tylerJensenButton) {
                            Text(tyler.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!tylerJensenButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10).background(Color(red: 0.933, green: 0.933, blue: 0.933))
                    }
                    if (zach.exists) {
                        Toggle(isOn: $zachSaetrumButton) {
                            Text(zach.getname())
                        }.simultaneousGesture(TapGesture().onEnded
                                              {
                            if (!zachSaetrumButton) {
                                game1.players += 1
                            }
                            else {
                                game1.players -= 1
                            }
                        }).padding(10)
                    }
                }
            }.frame(maxWidth: .infinity, alignment: .leading).border(Color(hue: 0.0, saturation: 0.0, brightness: 0.642))
            HStack() {
                Spacer()
                if (game1.oppGoals == game1.myGoals) {
                    Button("GAME OVER") {
                        
                    }.padding().background(lightGray).cornerRadius(30).accentColor(.gray)
                } else {
                    
                
                    NavigationLink(destination: SeasonView()) {
                        Text("GAME OVER")
                            .padding().background(.red)
                    }.simultaneousGesture(TapGesture().onEnded{
                        if (game1.myGoals > game1.oppGoals) {
                            game1.wins += 1
                        }
                        else {
                            game1.loss += 1
                        }
                        game1.oppGoals = 0
                        game1.myGoals = 0
                    }).cornerRadius(30).accentColor(.black)
                }
                Spacer()
                if (game1.myGoals == 0 && game1.oppGoals == 0 && game1.wins == 0 && game1.loss == 0) {
                        Button("STATS") {
                        
                        }.padding().background(lightGray).cornerRadius(30).accentColor(.gray)
                } else {
                    NavigationLink(destination: PointsPlayedView()) {
                        Text("STATS")
                            .padding().background(.gray).accentColor(.black)
                    }.cornerRadius(30)
                }
                Spacer()
                if (game1.players == 7) {
                    NavigationLink(destination: PointInProgressView()) {
                        Text(" SET ").font(.system(size : 40)).fontWeight(.bold)
                    }.simultaneousGesture(TapGesture().onEnded
                                          {
                        if (jordanKerrButton) {
                            jordan.turnOnField()
                            jordan.increment()
                        }
                        if (joeMerrillButton) {
                            joe.turnOnField()
                            joe.increment()
                        }
                        if (jacobMillerButton) {
                            jmills.turnOnField()
                            jmills.increment()
                        }
                        if (andrewStephenButton) {
                            asteph.turnOnField()
                            asteph.increment()
                        }
                        if (loganClarkeButton) {
                            logan.turnOnField()
                            logan.increment()
                        }
                        if (lukeYorgasonButton) {
                            luke.turnOnField()
                            luke.increment()
                        }
                        if (austinRichButton) {
                            austin.turnOnField()
                            austin.increment()
                        }
                        if (brodyDobsonButton) {
                            brody.turnOnField()
                            brody.increment()
                        }
                        if (brandonJordanButton) {
                            bj.turnOnField()
                            bj.increment()
                        }
                        if (jacksonGardnerButton) {
                            jackson.turnOnField()
                            jackson.increment()
                        }
                        if (jacobZundelButton) {
                            jz.turnOnField()
                            jz.increment()
                        }
                        if (jonathanMerrillButton) {
                            johnny.turnOnField()
                            johnny.increment()
                        }
                        if (shawnWilkeyButton) {
                            shawn.turnOnField()
                            shawn.increment()
                        }
                        if (bryceKerrButton) {
                            bryce.turnOnField()
                            bryce.increment()
                        }
                        if (chadYorgasonButton) {
                            chad.turnOnField()
                            chad.increment()
                        }
                        if (fletcherMillerButton) {
                            fletch.turnOnField()
                            fletch.increment()
                        }
                        if (kaltenTooneButton) {
                            kalten.turnOnField()
                            kalten.increment()
                        }
                        if (porterOylerButton) {
                            porter.turnOnField()
                            porter.increment()
                        }
                        if (taylorWilliamsButton) {
                            taylor.turnOnField()
                            taylor.increment()
                        }
                        if (andrewMillerButton) {
                            andrew.turnOnField()
                            andrew.increment()
                        }
                        if (evanMillerButton) {
                            evan.turnOnField()
                            evan.increment()
                        }
                        if (fischerDastrupButton) {
                            fischer.turnOnField()
                            fischer.increment()
                        }
                        if (isaacRasmussenButton) {
                            isaac.turnOnField()
                            isaac.increment()
                        }
                        if (jensenWellsButton) {
                            jensen.turnOnField()
                            jensen.increment()
                        }
                        if (johnHanniButton) {
                            hanni.turnOnField()
                            hanni.increment()
                        }
                        if (jonathanButton) {
                            jonathan.turnOnField()
                            jonathan.increment()
                        }
                        if (tylerJensenButton) {
                            tyler.turnOnField()
                            tyler.increment()
                        }
                        if (zachSaetrumButton) {
                            zach.turnOnField()
                            zach.increment()
                        }
                        jordanKerrButton = false
                        joeMerrillButton = false
                        jacobMillerButton = false
                        andrewStephenButton = false
                        loganClarkeButton = false
                        lukeYorgasonButton = false
                        austinRichButton = false
                        brodyDobsonButton = false
                        brandonJordanButton = false
                        jacksonGardnerButton = false
                        jonathanMerrillButton = false
                        shawnWilkeyButton = false
                        bryceKerrButton = false
                        chadYorgasonButton = false
                        fletcherMillerButton = false
                        kaltenTooneButton = false
                        porterOylerButton = false
                        taylorWilliamsButton = false
                        andrewMillerButton = false
                        evanMillerButton = false
                        fischerDastrupButton = false
                        isaacRasmussenButton = false
                        jensenWellsButton = false
                        johnHanniButton = false
                        jonathanButton = false
                        tylerJensenButton = false
                        zachSaetrumButton = false
                        areWeOnOffense = !areWeOnOffense
                    }).padding(10)
                        .background(.green).cornerRadius(300).accentColor(.black)
                }
                else {
                    NavigationLink(destination: PointInProgressView()) {
                        Text(" SET ").font(.system(size : 40)).fontWeight(.bold).padding(10).background(lightGray).cornerRadius(300).accentColor(.gray)
                    }
                }
                Spacer()
            }
            
        }.padding(1)
        
    }
}

struct PointTrackerView_Previews: PreviewProvider {
    static var previews: some View {
        PointTrackerView()
    }
}
