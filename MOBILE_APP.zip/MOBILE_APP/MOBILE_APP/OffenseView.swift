//
//  DidWeScoreView.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/11/22.
//

import SwiftUI

struct OffenseView: View {

    
    var body: some View {
        VStack {
            Spacer()
        Text("On Offense...").font(.system(size : 40)).fontWeight(.bold)
            Spacer()
            HStack {
                NavigationLink(destination: TurnoverView()) {
                    Text("Turnover").font(.system(size : 30)).fontWeight(.bold)
                }.simultaneousGesture(TapGesture().onEnded{
                    
                }).padding().background(.green).cornerRadius(20).accentColor(.black)
                NavigationLink(destination: WhoScoredView()) {
                    Text("GOAL!").font(.system(size : 30)).fontWeight(.bold)
                }.simultaneousGesture(TapGesture().onEnded{
                    game1.incMe()
                }).padding().background(.green).cornerRadius(20).accentColor(.black)
                
            }
        }
    }
}

struct Offense_Previews: PreviewProvider {
    static var previews: some View {
        OffenseView()
    }
}
