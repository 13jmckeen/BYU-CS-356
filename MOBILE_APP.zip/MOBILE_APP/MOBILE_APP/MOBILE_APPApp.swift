//
//  MOBILE_APPApp.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/6/22.
//

import SwiftUI

@main
struct MOBILE_APPApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
