//
//  DefenseView.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/29/22.
//

import SwiftUI

struct DefenseView: View {
    var body: some View {
        VStack {
            Spacer()
        Text("On Defense...").font(.system(size : 40)).fontWeight(.bold)
            Spacer()
            HStack {
                NavigationLink(destination: DidAnyoneBlockView()) {
                    Text("Turnover").font(.system(size : 30)).fontWeight(.bold)
                }.simultaneousGesture(TapGesture().onEnded{
                    
                }).padding().background(.green).cornerRadius(20).accentColor(.black)
                NavigationLink(destination: PointTrackerView()) {
                    Text("OPP GOAL").font(.system(size : 30)).fontWeight(.bold)
                }.simultaneousGesture(TapGesture().onEnded{
                    game1.incThem()
                    jordan.isOnField = false
                    joe.isOnField = false
                    jmills.isOnField = false
                    asteph.isOnField = false
                    logan.isOnField = false
                    luke.isOnField = false
                    austin.isOnField = false
                    brody.isOnField = false
                    jackson.isOnField = false
                    bj.isOnField = false
                    johnny.isOnField = false
                    jz.isOnField = false
                    shawn.isOnField = false
                    bryce.isOnField = false
                    chad.isOnField = false
                    fletch.isOnField = false
                    kalten.isOnField = false
                    porter.isOnField = false
                    taylor.isOnField = false
                    andrew.isOnField = false
                    evan.isOnField = false
                    fischer.isOnField = false
                    isaac.isOnField = false
                    jensen.isOnField = false
                    hanni.isOnField = false
                    tyler.isOnField = false
                    jonathan.isOnField = false
                    zach.isOnField = false
                }).padding().background(.green).cornerRadius(20).accentColor(.black)
                
            }
        }
    }
}

struct DefenseView_Previews: PreviewProvider {
    static var previews: some View {
        DefenseView()
    }
}
