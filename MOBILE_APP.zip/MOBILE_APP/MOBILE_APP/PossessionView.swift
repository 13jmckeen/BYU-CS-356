//
//  PossessionView.swift
//  MOBILE_APP
//
//  Created by Justin McKeen on 11/11/22.
//

import SwiftUI

struct PossessionView: View {
    @State var possession = false
    var body: some View {
        HStack {
            NavigationLink(destination: PointTrackerView()) {
                Button("Offense?") {
                    possession = true
                }
                Text("Offense?")
                    .padding(20)
                    .background(.green)
                
            }
            NavigationLink(destination: PointTrackerView()) {
                Text("Defense?")
                    .padding(20)
                    .background(.green)
            }
        }
    }
}

struct PossessionView_Previews: PreviewProvider {
    static var previews: some View {
        PossessionView()
    }
}
