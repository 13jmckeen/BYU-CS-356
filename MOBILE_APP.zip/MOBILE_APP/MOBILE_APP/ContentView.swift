//
//  ContentView.swift
//  MOBILE_APP   
//
//  Created by Justin McKeen on 11/6/22.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Ultimate Stats")
                    .font(.largeTitle)
                Text("")
                Text("")
                Text("Your home for")
                    .foregroundColor(Color.gray)
                Text("gathering data").foregroundColor(Color.gray)
                Text("on ultimate frisbee").foregroundColor(Color.gray)
                Spacer()
            
                Spacer()
                NavigationLink(destination: NewPlayerView()) {
                    Text("START SEASON    ->").fontWeight(.black)
                }.frame(width: 200, height: 30).padding().background(.green).cornerRadius(20).accentColor(.black)
                Spacer()
            }
        }

    }
}

// SEAN INPUT: no toggles just buttons, +/- for blocks, goals/assists only1 person, search bar in menu for players? pts/played to stats, throwaways stat.


// SF Symbols (download)

/* NOTES
 VStack{}
 .cornerRadius(#degree)
 .bold()
 .padding()
 .resizable()
 */

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
